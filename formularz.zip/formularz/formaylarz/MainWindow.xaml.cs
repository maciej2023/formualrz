﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace FormularzUzytkownika
{
    public partial class MainWindow : Window
    {
        
        private bool _czyAktualizuje = false;

        public MainWindow()
        {
            InitializeComponent();

            dpDataUrodzenia.DisplayDateEnd = DateTime.Today;
            dpDataUrodzenia.DisplayDateStart = DateTime.Today.AddYears(-120);

            
            txtImie.TextChanged += TxtImie_TextChanged;
            txtNazwisko.TextChanged += TxtNazwisko_TextChanged;
            txtTelefon.TextChanged += TxtTelefon_TextChanged;
        }

        private bool CzyDozwoloneLitery(string tekst)
        {
            return tekst.All(znak =>
                char.IsLetter(znak) ||
                znak == ' ' ||
                znak == '-');
        }

        private bool CzyDozwolonyTelefon(string tekst)
        {
            return Regex.IsMatch(tekst, @"^\+?\d{0,9}$");
        }

        private void TxtImie_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_czyAktualizuje) return;

            TextBox pole = (TextBox)sender;
            if (!CzyDozwoloneLitery(pole.Text))
            {
                _czyAktualizuje = true;
                txtBlad.Text = "Imię: Cyfry i znaki specjalne są całkowicie zablokowane.";

               
                CofnijZmiane(pole, e);
                _czyAktualizuje = false;
            }
            else
            {
                txtBlad.Text = "";
            }
        }

        private void TxtNazwisko_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_czyAktualizuje) return;

            TextBox pole = (TextBox)sender;
            if (!CzyDozwoloneLitery(pole.Text))
            {
                _czyAktualizuje = true;
                txtBlad.Text = "Nazwisko: Cyfry i znaki specjalne są całkowicie zablokowane.";

                CofnijZmiane(pole, e);
                _czyAktualizuje = false;
            }
            else
            {
                txtBlad.Text = "";
            }
        }

        private void TxtTelefon_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_czyAktualizuje) return;

            TextBox pole = (TextBox)sender;
            if (!CzyDozwolonyTelefon(pole.Text))
            {
                _czyAktualizuje = true;
                txtBlad.Text = "Telefon: Dozwolone tylko cyfry (max 9) i '+' na początku.";

                CofnijZmiane(pole, e);
                _czyAktualizuje = false;
            }
            else
            {
                txtBlad.Text = "";
            }
        }


        private void CofnijZmiane(TextBox pole, TextChangedEventArgs e)
        {
            foreach (var zmiana in e.Changes)
            {
                int kursor = pole.SelectionStart;

             
                if (zmiana.AddedLength > 0)
                {
                    pole.Text = pole.Text.Remove(zmiana.Offset, zmiana.AddedLength);
                    pole.SelectionStart = Math.Max(0, kursor - zmiana.AddedLength);
                }
            }
        }

        private void btnPodsumowanie_Click(object sender, RoutedEventArgs e)
        {
            txtBlad.Text = "";

            string imie = txtImie.Text.Trim();
            string nazwisko = txtNazwisko.Text.Trim();
            string telefon = txtTelefon.Text.Trim();
            string informacje = txtInformacje.Text.Trim();

            if (string.IsNullOrWhiteSpace(imie))
            {
                Blad("Wpisz imię.");
                txtImie.Focus();
                return;
            }

            if (imie.Length < 3)
            {
                Blad("Imię musi mieć minimum 3 litery.");
                txtImie.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(nazwisko))
            {
                Blad("Wpisz nazwisko.");
                txtNazwisko.Focus();
                return;
            }

            if (nazwisko.Length < 3)
            {
                Blad("Nazwisko musi mieć minimum 3 litery.");
                txtNazwisko.Focus();
                return;
            }

            if (rbKobieta.IsChecked != true && rbMezczyzna.IsChecked != true)
            {
                Blad("Wybierz płeć.");
                return;
            }

            if (!dpDataUrodzenia.SelectedDate.HasValue)
            {
                Blad("Wybierz datę urodzenia.");
                return;
            }

            DateTime dataUrodzenia = dpDataUrodzenia.SelectedDate.Value.Date;
            DateTime dzisiaj = DateTime.Today;
            DateTime najstarszaData = dzisiaj.AddYears(-120);

            if (dataUrodzenia > dzisiaj)
            {
                Blad("Data urodzenia nie może być z przyszłości.");
                return;
            }

            if (dataUrodzenia < najstarszaData)
            {
                Blad("Wiek nie może przekraczać 120 lat.");
                return;
            }

            if (string.IsNullOrWhiteSpace(telefon))
            {
                Blad("Wpisz numer telefonu.");
                txtTelefon.Focus();
                return;
            }

            string cyfry = telefon.StartsWith("+") ? telefon.Substring(1) : telefon;

            if (cyfry.Length != 11)
            {
                Blad("Telefon musi zawierać dokładnie 9 cyfr. Znak + może wystąpić tylko na początku.");
                txtTelefon.Focus();
                return;
            }

            string plec = rbKobieta.IsChecked == true ? "Kobieta" : "Mężczyzna";

            string wynik =
                "PODSUMOWANIE DANYCH UŻYTKOWNIKA\n\n" +
                "Imię: " + imie + "\n" +
                "Nazwisko: " + nazwisko + "\n" +
                "Płeć: " + plec + "\n" +
                "Data urodzenia: " + dataUrodzenia.ToString("dd.MM.yyyy") + "\n" +
                "Telefon: " + telefon + "\n" +
                "Informacje dodatkowe: " + (string.IsNullOrWhiteSpace(informacje) ? "Brak" : informacje);

            MessageBox.Show(
                wynik,
                "Podsumowanie",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void Blad(string komunikat)
        {
            txtBlad.Text = komunikat;

            MessageBox.Show(
                komunikat,
                "Błąd walidacji",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }
}
